clear all;
close all;
badRelax = readmatrix("badRelax.txt");
badClench = readmatrix("badClench.txt");
goodRelax = readmatrix("goodRelax.txt");
goodClench = readmatrix("goodClench.txt");
dt = 500/1000000;
df = 1/(dt*6000);
%badRelax = badRelax - mean(badRelax);
%badClench = badClench - mean(badClench);
%goodRelax = goodRelax - mean(goodRelax);
%goodClench = goodClench - mean(goodClench);

filteredBadRelax = highpass(badRelax, 5, 2000) + mean(badRelax);
filteredBadClench = highpass(badClench, 5, 2000) + mean(badClench);
filteredGoodRelax = highpass(goodRelax, 5, 2000);
filteredGoodClench = highpass(goodClench, 5, 2000);
figure(1);
hold on;
%plot(goodRelax);
%plot(filteredGoodRelax);
plot(badRelax);
plot(filteredBadRelax);
figure(2)
hold on;
%plot(goodClench);
%plot(filteredGoodClench);
plot(badClench);
plot(filteredBadClench);
figure(3);
hold on;
freqDom = fft(badRelax, 6000);
ffreqDom = fft(filteredBadRelax, 6000);
plot((1:3000)*df, abs(freqDom(1:3000)*dt));
plot((1:3000)*df, abs(ffreqDom(1:3000)*dt));
%plot((1:6000)*df, abs(fft(badClench, 6000)*dt));
%plot((1:6000)*df, abs(fft(goodRelax, 6000)*dt));
%plot((1:6000)*df, abs(fft(filteredGoodRelax, 6000)*dt));
%figure(4)
%hold on;
%plot((1:6000)/(2*pi), abs(fft(goodClench, 6000)));
%plot((1:6000)/(2*pi), abs(fft(filteredGoodClench, 6000)));
badData = [filteredBadRelax(1), 1];
for i = 2:5000
    badData = [badData; filteredBadRelax(i), 1];
end
for i = 1:5000
    badData = [badData; filteredBadClench(i), 0];
end

badTest = [filteredBadRelax(5001), 1];
for i = 5002:6000
    badTest = [badTest; filteredBadRelax(i), 1];
end
for i = 5001:6000
    badTest = [badTest; filteredBadClench(i), 0];
end
%classificationLearner;