clear all;
close all;
fRelax = readmatrix("filteredRelax.txt");
fClench = readmatrix("filteredClench.txt");

len = length(fRelax);
dt = 500/1000000;
df = 1/(dt*len);

windowSize = 100;
fRelaxM = zeros(len-windowSize);
fClenchM = zeros(len-windowSize);
for i = 1:len-windowSize
        fRelaxM(i) = mean(abs(fRelax(i : i + windowSize)));
        fClenchM(i) = mean(abs(fClench(i : i + windowSize)));
end

figure(1)
hold on;
plot(fClench);
plot(fRelax);
figure(3)
hold on;
plot(fClenchM);
plot(fRelaxM);

figure(2);
hold on;
freqDomR = fft(fRelax, len);
freqDomC = fft(fClench, len);
plot((1:len/2)*df, abs(freqDomC(1:floor(len/2))*dt));
plot((1:len/2)*df, abs(freqDomR(1:floor(len/2))*dt));