clear all;
close all;
top = readmatrix("top.txt");
bot = readmatrix("normal.txt");
len = length(top);
dt = 500/1000000;
df = 1/(dt*len);

top = top - mean(top);
bot = bot - mean(bot);
topStop = bandstop(top, [59, 61], 2000);
botStop = bandstop(bot, [59, 61], 2000);
topStop = lowpass(topStop, 967.5, 2000);
botStop = lowpass(botStop, 967.5, 2000);
topStop = highpass(topStop, 20, 2000);
botStop = highpass(botStop, 20, 2000);
%topStop = bandstop(topStop, [179, 181], 2000);
%botStop = bandstop(botStop, [179, 181], 2000);
%topStop = bandstop(topStop, [299, 301], 2000);
%botStop = bandstop(botStop, [299, 301], 2000);
%topStop = bandstop(topStop, [419, 421], 2000);
%botStop = bandstop(botStop, [419, 421], 2000);
%topStop = bandstop(topStop, [539, 541], 2000);
%botStop = bandstop(botStop, [539, 541], 2000);

figure(1);
hold on;
plot(1:6000, top(1:6000));
plot(1:6000, bot(1:6000));

figure(2)
hold on;
freqDomT = fft(top, len);
freqDomB = fft(bot, len);
freqDomTS = fft(topStop, len);
freqDomBS = fft(botStop, len);
plot((1:len/2)*df, abs(freqDomT(1:floor(len/2))*dt));
plot((1:len/2)*df, abs(freqDomB(1:floor(len/2))*dt));

figure(3)
hold on;
plot(1:6000, topStop(1:6000));
plot(1:6000, botStop(1:6000));

figure(4)
hold on;
plot((1:len/2)*df, abs(freqDomTS(1:floor(len/2))*dt));
plot((1:len/2)*df, abs(freqDomBS(1:floor(len/2))*dt));
